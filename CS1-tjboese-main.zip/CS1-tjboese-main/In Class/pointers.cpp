/*

Tyrel Boese

Pointers


*/

#include <iostream>
#include <string>
#include <cassert>

using namespace std;

int main(int argc, char *argv[]) {
int num1, num2, num3;
num1 = 42;


cout << "num1: " << num1 << endl;
cout << "&num1: " << &num1 << endl;
cout << "&num2: " << &num2 << endl;
cout << "&num3: " << &num3 << endl;
cout << "*(&num1): " << *(&num1) << endl;




return 0;

}