/*
Name: Tyrel Boese
All about the data...types...
*/

#include <iostream>

using namespace std;

int main() {
    // char someChar;
    // //char SomeChar; don't do this lol
    // //char SOMECHAR;
    // //char SoMeChAr;
    // int someInt;
    // float thisIsAFloat;
    // //double whatAmIGoingToUseThisForInThisProgram;

    // someChar = 'J';
    // someInt = 42;
    // thisIsAFloat = 42.95;

    // cout << "someInt: " << someInt << endl;
    // cout << "someChar: " << someChar << endl;
    // cout << "thisIsAFloat: " << thisIsAFloat << endl;

    // someChar = 'B';
    // someInt = -6000;
    // thisIsAFloat = -324832.3;

    // cout << "someInt: " << someInt << endl;
    // cout << "someChar: " << someChar << endl;
    // cout << "thisIsAFloat: " << thisIsAFloat << endl;


    // int number1;

    // number1 = 2147483646;

    // cout << "number1: " << number1 << endl;

    // number1 = number1 + 1;

    // cout << "number1: " << number1 << endl;

    // number1 = number1++;

//     string firstName;
//     string lastName;
//     char middleInitial;
//     string fullName

//     cout << "What is your first name?";
//     // cin >> firstName;
//     getline(cin, firstName);

//     cout << "What is your Last Name?";
//     // cin >> lastName;
//     getline(cin, lastName);

//     cout << "What is your middle initial?";
//     cin >> middleInitial;
//     // middleInitial - 'J';

   
//    fullName = firstName + " " + middleInitial + " " + lastName;
//    cout << "welcome"  << fullName << " to our program." << endl;

    return 0;
}