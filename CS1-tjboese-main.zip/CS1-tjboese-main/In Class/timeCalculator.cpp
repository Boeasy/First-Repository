#include <iostream>

using namespace std;

int main () {
    unsigned int numSeconds;
    unsigned int numHours;
    unsigned int numMinutes;
    unsigned int remSeconds;
    string firstName;


    cout << "Please enter your first name: ";
    getline(cin, firstName);

    cout << "Welcome to our time calculator " << firstName << "." << endl;

    cout << "Please enter the number of seconds you wish to calculate from: ";
    cin >> numSeconds;

    // cout << "DEBUG: numSeconds: " << numSeconds << endl;
    numHours = ((numSeconds / 3600)%12)+1;
    numMinutes = (numSeconds / 60)%60;
    remSeconds = numSeconds%60;


    cout << numHours << endl;
    cout << numMinutes << endl;
    cout << "The time given " << numSeconds << " is: " << numHours << ":" << numMinutes << ":" << remSeconds << endl;

    return 0;
}