// Name: Tyrel Boese

// Multiplication Table Printer

#include <iostream>
#include <string>
#include <cassert>
#include <cmath>

using namespace std;

int main() {
int tSize, stepSize = 1;

cout << "enter in a number to create a multiplication table!" << endl;
cin >> tSize;

int ** multTable = new int*[tSize];

for (int i=0; i < tSize; i++) {
    multTable[i]=new int[tSize];
}

for (int i=1; i <= tSize; i++) {
    for (int j=1; j <= tSize; j++){
        multTable[i][j] = i*j;
    }
}

for (int i=0; i <= tSize; i++) {
    for (int j=0; j <= tSize; j++){
        cout << multTable[i][j] << "   ";
    }
}

for (int i; i < tSize; i++) {
    delete[] multTable[i];
        delete[] multTable;
}

    return 0;


}

//---------------------------------------------
// int prompt(int);
// void printTable(unsigned int, int&);
// int modifyTable(unsigned int);
//
//
// int prompt() {
//     int tSize;
// cout << "Please enter the size of our multiplication table: ";
// cin >> tSize;
// return tSize;
// }

// void printTable(int tSize, int &multtable[][1]) {
// for (int i=1; i < tSize; i++) {
//     for (int j=1; j < tSize; j++) {
//         cout << multtable[&i][&j];
//     }
// }
// }

// int myArray() {
//     createArray(size)
// }

// void modifyTable(int size, int &multtable[][2]) {

// for (int i=1; i < size; i++) {
//     for (int j=1; j < size; j++) {
//         *multtable[i][j]=i*j;
//     }
// }

// }

// int main(int argc, char * argv[]) {
// //size of multtable
// int size = 0;
// string name;
// size = prompt();
// int multtable[1][1]=
// {0}
// ;

// modifyTable(size, &multtable);

// printTable(size, &multtable);

//     return 0;
// }
//-------------------------------------------old-code--------

