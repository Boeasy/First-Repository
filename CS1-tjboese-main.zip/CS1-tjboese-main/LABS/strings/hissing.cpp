/*
Kattis - Hissing Microphone Problem

By: Tyrel Boese
Date: 11-1-2023

Hissing Microphone Problem Statement: https://open.kattis.com/problems/hissingmicrophone
Algorithm steps:
1. Read string
2. find "ss" substring in the string
    - if found, print "hiss"
    - otherwise, print "no hiss"
*/

#include <iostream>
#include <string>
#include <cassert>

using namespace std;

// function prototypes
string answer(const string &line);
void testAnswer();
void solve();

int main(int argc, char* argv[]) {
    if (argc == 2 and string(argv[1]) == "test")
        testAnswer();
    else
        solve();
}

string answer(const string &line) {
    int hisscheck=0;
    // FIXME3
    // implment algorithm step 2
    // return "hiss" if ss is found in line
    // otherwise, return "no hiss"
    //  #FIXED

   for (auto &ch : line){
    switch (ch){
        case 's': 
        hisscheck++;
        if (hisscheck > 1){
            goto answer;
        }
        break;
        default:
        hisscheck = 0;
        break;
    }
        }
        answer:
        switch (hisscheck){
            case 0:
            return "no hiss";
            case 1:
            return "no hiss";
            default:
            return "hiss";}

}

// unit testing answer()
void testAnswer() {
    // FIXME4 #FIXED
    // write at least two test cases to test answer()
    string test1 = "snake";
    string test2 = "sssssssssss";
    // cout << answer(test1) << endl; DEBUG
    // cout << answer(test2) << endl; DEBUG
    assert(answer(test1) == "no hiss");
    assert(answer(test2) == "hiss");
    
    cout << "\033[36m" << endl;
    
    /*
    cassert answer( test case ) = hiss / no hiss
    */
    cerr << "All test cases passed!\n";
}

// solving the problem for kattis
void solve() {
    string line;
    cout << "enter a string up to 30 characters" << endl;
    // string consists of only lowercase letters (no spaces) upto 30 chars
    // FIXME5 #FIXED
    // read string into line
    getline(cin, line);
    /*
    1. cin -> line
        -limit characters?
    2.
    
    */
    cout << answer(line) << endl;
}