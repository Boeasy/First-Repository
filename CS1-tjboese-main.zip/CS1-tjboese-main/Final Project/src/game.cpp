//game functions

#include <iostream>
#include <string>
#include "game.h"
#include "format.h"
#include "tictacfoe.h"

namespace game {
    // game funtions and variables here....
    bool checksquare(int square, char token){
        //checks for token at board[square]
        if (board[square] == token){
            return true;
        }
        return false;
    }

    void chooseSquare(char board[9], char token){
        int input;
        //enter two integers between 1-9 separated by a space to indicate your selection
        std::cout << "Your Turn! Select a Square (1-9)" << std::endl;
        do {
            std::cin >> input;
            if (board[input - 1] == token){
                std::cout << "You've already picked that square!" << std::endl;
            }            
            if (board[input - 1] == pctoken){
                std::cout << "That square is taken!" << std::endl;
            }
            std::cout << "You've chosen square: " << input << std::endl;
        } while (board[input - 1] != ' ');
        //change board[input]
        board[input - 1] = token;

    }

    bool checkLine(int pos, int step){ //found arithmetic progression on codereview.stackexchange.com/questions/268345/tic-tac-toe-in-c-with-classes
        char token = board[pos];
        pos += step;
        if (board[pos] != token) {return false;}
        pos += step;
        if (board[pos] != token) {return false;}
        return true;
    }



    char gameEnd(){
        /*
        fileio for stat recording
        ask player to play again or go to main menu
        */
       char input;

       std::cout << "play again? Y/N" << std::endl;
        do{
        std::cin >> input;
        } while (input != 'y' && input != 'Y' && input != 'n' && input != 'N');

        return input;

    }

    bool checkWin(char board[9], char token){
        /*
        check board for a win...
        */
       if (
        // horizontals..
        (board[0] == token && board[1] == token && board[2] == token)||
        (board[3] == token && board[4] == token && board[5] == token)||
        (board[6] == token && board[7] == token && board[8] == token)||
        // verticals
        (board[0] == token && board[3] == token && board[6] == token)||
        (board[1] == token && board[4] == token && board[7] == token)||
        (board[2] == token && board[5] == token && board[8] == token)||
        //diagonals
        (board[0] == token && board[4] == token && board[8] == token)||
        (board[2] == token && board[4] == token && board[6] == token)
       )
       {
        return true;

       }
       return false;
       //todo: add some sort of logic for a draw?
    }

    void XsorOs(char& token, char& pctoken, bool& yourTurn){    // choose Xs or Os
        /*
        cout "X's or O's?"
        do while loop until token = X or O
        pctoken = the other one
        set bool yourturn = true for X or false for O
        */
       std::cout << "X's or O's?" << std::endl;

       do {
        std::cin >> token;
       } while (token != 'X' && token != 'O');

       if (token == 'X') {
        pctoken = 'O';
        yourTurn = true;
        }
        if (token == 'O'){
            pctoken = 'X';
            yourTurn = false;
        }

    } 

    char gameplay(){
        gameDifficulty = 2;
        int counter = 0;
        do { //first turn excluded because can't win on turn 1 ... do while loop
                format::printBoard(board);
                if (yourTurn == true){
                    chooseSquare(board, token);
                    yourTurn = false;
                    counter++; //check for draw
                    continue; //break out of do while loop so not stuck in infinite back and forth...
                }
                if (yourTurn == false){
                    CompAI::pcTurn(gameDifficulty, pctoken, token);
                    yourTurn = true;
                    counter++; //check for draw
                    continue;
                }
            } 
            while (!checkWin(board, token) && !checkWin(board, pctoken) && counter < 9); // while a win hasn't been declared, keep going
        //return character of winner, or d for draw;
        if (checkWin(board, token)){
            return token;
        } 
        if (checkWin(board, pctoken)){
            return pctoken;
        }
        return 'd';
    }

    void gameStart(){
        char keepgoing = 'Y';
        token = 'X'; // initializing player token to Xs
        pctoken = 'O'; // default pc is Os
        yourTurn = true; //default it's your turn

        do {
        XsorOs(token, pctoken, yourTurn); // sets player token to X or O and pc to opposite
        for (int i = 0; i < 9; i++){
            board[i] = ' '; // reset board
        }

        char result = gameplay();

        if (result == token){
            std::cout << "Player wins!" << std::endl;

        }
        if (result == pctoken){
            std::cout << "PC wins!" << std::endl;

        }
        if (result == 'd'){
            std::cout << "It's a Draw!" << std::endl;
        }

        keepgoing = gameEnd();

        }
        while (keepgoing != 'N' || keepgoing != 'n');
        /*
        to do add in some file IO for scores...
        
        */
    }


} // end of namespace bracket don't delete
