//header for computer AI
#pragma once

#include <string>

namespace CompAI {
    int diff;

    bool win();
    bool blockwin();
    bool fork();
    bool blockfork();
    bool center();
    bool oppositecorner();
    bool emptycorner();
    bool emptyside();
    int randomsquare();

    void pcTurn(int, char, char);

}