//mainmenu functions

#include <string> // place holder
#include <iostream>
#include "mainmenu.h"
#include "format.h"
#include "game.h"

namespace mainMenu {
    // mainMenu funtions and vars here....
    std::string player;
    int difficulty;
    bool endgame;

    void option(){
        int input;
        endgame = false;
        do {
        format::mainMenu();
        std::cin >> input;

        switch (input){
            case 1: // Choose Player
            choosePlayer();
            break;        
            case 2: // Change Difficulty
            game::gameDifficulty = changeDifficulty();
            break;
            case 3: // Leaderboard
            leaderBoard();
            break;
            case 4: // Player Stats
            playerStats();
            break;
            case 5: // Start Game
            game::gameStart();
            break;
            case 6: // Exit
                endgame = quit();
                break;
            break;
            default: // Print Menu Again
            format::mainMenu();
            break;
        }
        } while (!endgame);

    }

    void choosePlayer(){
        /*
        prompt for username - getline(cin, playername)
        send back to menu
        */
       std::getline(std::cin, player);
    }

    int changeDifficulty(){
        /*
        cout 'current difficulty'
        cout difficulty levels 1-9 + explanations?
        do while loop (until valid input)
        cin >> difficulty
        cout << difficulty level is "_"

        send back to menu...
        */

       do {
        std::cout<< "Enter the difficulty level (1-6)" << std::endl;
        std::cin >> difficulty;
       } while (difficulty != 0 && difficulty != 1 && difficulty != 2 &&
       difficulty != 3 && difficulty != 4 && difficulty != 5 && difficulty != 6 );
        return difficulty;
    }

    void leaderBoard(){

        // format::printScores();
        /*
        print leaderboard
        wait for user input

        go back to menu
        */
    }

    void playerStats(){
        /*
        print current player stats

        wait for user input

        go back to menu
        
        */
    }

    bool quit(){
        /*
        exit program...
        */
       char input;
       std::cout << "Exit? (Y/N)" << std::endl;
       std::cin >> input;

       if (input != 'N'){
        return true;
       }
        return false;
    }

}