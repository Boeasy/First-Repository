//header file for game logic
#pragma once

#include <string>

namespace game {
    size_t boardsize;
    char board[9] = {' ',' ',' ',' ',' ',' ',' ',' ',' '};
    char token;
    char pctoken;
    bool yourTurn;
    int gameDifficulty;

    void gameStart(); //start game
    char gameEnd(); // output game stats - replay or go to main menu

    void XsorOs(char& , char&, bool&); // choose Xs or Os

    bool checksquare(int, char); // checks if square is taken (for random & player choose)
    bool checkWin(); // check if board solved 
    bool checkLine(int, int, char);

    void chooseSquare(char[9], char); // player chooses a square


}