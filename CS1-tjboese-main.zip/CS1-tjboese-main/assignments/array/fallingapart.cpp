/*
Tyrel Boese
CSCI-111 HW 8
Array / falling apart kattis


input the number of integers (between 1 and 15)
input that number of integers between 1 and 100 separated by space(s);
store these numbers as an array
sort the array in descending order
take the sum of odd index numbers for alice's pieces
take the sum of even index numbers for bob's pieces
output in a single line the sums of alice's and bob's pieces respectively
*/

#include <string>
#include <iostream>
#include <cassert>
using namespace std;

void sort(int[], size_t );
void findSums(int[], int&, int&, size_t );
void printArr(int[], size_t);

void test(int& , int&);

int main(int argc, char* argv[]){
int alice = 0;
int bob = 0;
size_t numpieces = 0;
if (strcmp(argv[1], "test") == 0){
    test(alice, bob);

    return 0;}




cout << "enter the number of pieces: " << endl;
cin >> numpieces;

cout << "enter in the value of each piece separated by a space" << endl;
int pieces[numpieces];
for (int i=0; i< numpieces; i++){
    int tmp;
    cin >> tmp;
    pieces[i]=tmp;
}
// DEBUG:
//printVec(pieces);
sort(pieces, numpieces);
findSums(pieces, alice, bob, numpieces);

cout << "Alice's Total: " << alice << " Bob's Total: " << bob << endl;
//cout << alice << bob; kattis output
}

void sort(int pieces[], size_t size){
    bool sorted = true;
    for (size_t i=0; i < size-1; i++){
        sorted = true;
        for (size_t j=0; j < size-1-i; j++){
            if (pieces[j] < pieces[j+1]){
                int tmp = pieces[j];
                pieces[j]=pieces[j+1];
                pieces[j+1]=tmp;
                sorted = false;
            }
        }
        if (sorted) {break;}
    }
}


void findSums(int pieces[] ,int& alice, int& bob, size_t size){
    alice = 0;
    bob = 0;
    printArr(pieces, size);
    for (int n = 0; n < size; n++){
        if (n % 2 != 1){
            alice += pieces[n];
            continue;
        } 
        bob += pieces[n];
            DEBUG:
            cout << "n: " << n << endl;
            cout << "pieces[n]" << pieces[n] << endl;
    }
}
void printArr(int pieces[], size_t size){
    for (int n=0; n < size; n++){
        cout << "pieces[" << n << "]" << "=" << pieces[n]<< endl;
    }
}
void test(int& alice, int& bob){
    alice = 0;
    bob = 0;
    int pieces[5] = {5,4,3,2,1};
    size_t arrsize = 5;
    findSums(pieces, alice, bob, arrsize);
    cout << alice << bob << endl;
    assert(alice == 9);
    assert(bob == 6);
    alice = 0;
    bob = 0;
    int pieces2[9] = {9, 8, 7, 6, 5,4,3,2,1};
     arrsize = 9;
    findSums(pieces2, alice, bob, arrsize);
        cout << alice << bob << endl;
    assert(alice == 25);
    assert(bob == 20);    
    alice = 0;
    bob = 0;
    int pieces3[4] = {625, 125, 75, 25};
     arrsize = 4;
    findSums(pieces3, alice, bob, arrsize);
        cout << alice << bob << endl;
    cout << alice << endl;
    assert(alice == 700);
    assert(bob == 150);

    cout << "all tests passed!" << endl;
}
