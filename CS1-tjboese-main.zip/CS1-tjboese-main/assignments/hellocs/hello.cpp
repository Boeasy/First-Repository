/*
Name: Tyrel Boese

This is a hello world program

*/

//This is to print out
#include <iostream>

//this is the standard namespace
using namespace std;

//This is the first function all c/C++ programs have to have
int main() {
    cout << "Hello World" << endl;//This prints out to the console (or should)

    return 0;
    }
