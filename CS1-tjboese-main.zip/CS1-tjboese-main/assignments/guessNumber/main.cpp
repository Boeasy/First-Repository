/*
Tyrel Boese
csci-111
hw 5 guess numbers game

algorithm steps:
Game start
Computer generates random number
loop start
player guesses a number
guessed number is compared to random number
return value is different based on the comparison
player is informed of result based on return value
based on that return value game reloops or breaks out
counter increases
if counter goes over 6 game ends
if game ends with a win, win counter increases, either way game counter increases
*/

#include <iostream>

using namespace std;
int randomNumber();
int readNumber();
int checkGuess(int, int);
void Game(int&, int&);


int randomNumber() {
    int rando = rand() % 20;
    //returns random number 0-20
    return rando;
}
int readNumber(){
    int input = -1;
    do {
        cout << "enter a number between 0-20" << endl;
        cin >> input;}
        while (input < 0 || input > 20);
        return input;
}
int checkGuess(int num1, int num2) {
//write 3 test cases for this function using a test function
 /*
    takes two integers compares the two numbers and returns the following result:
returns 0 if the numbers are equal
returns -1 if the first number is less than second
returns 2 otherwise
    */
int guesscheck = 2;
// int rando = randomNumber(); //temporary - assign random number inside game function...
if (num1 == num2) {
    guesscheck = 0;
}
if (num1 < num2){
    guesscheck = -1;
}
return guesscheck;
}

void Game(int& gamecounter, int& wincounter){
int guesscount = 0;
int num2 = randomNumber();
int num1 = 0;

do {
    num1 = readNumber();
    int result = checkGuess(num1, num2);
    switch(result){
        case 0:
        goto win_skip;
        case -1:
        guesscount++;
        cout << "Too low" << endl;
        break;
        case 2:
        guesscount++;
        cout << "too high!" << endl;
        break;    }
}
while (guesscount < 6);

win_skip:
switch(guesscount){
    case 6:
    cout << "better luck next time" << endl;
    cout << "Your number was: " << num1 << endl;
    cout << "The random number was: " << num2  << endl;
    gamecounter++;
    break;
    default:
    cout << "you guessed it" << endl;
    cout << "Your number was: " << num1 << endl;
    cout << "The random number was: " << num2  << endl;
    gamecounter++;
    wincounter++;
    break;
}
}

int main(int argc, char * argv[]){
int gamecounter=0;
int wincounter=0;

char keepgoin = 'y';
srand(time(0));
string name;
cout << "Welcome to the number guessing game, what is your name?" << endl;
cin >> name;
cout << "Hello, " << name << " Please guess a number from 0 to 20, you have 6 tries." << endl;

do {
Game(gamecounter, wincounter);
cout << "Continue? Enter y to try again" << endl;
cin >> keepgoin;
}
while (keepgoin == 'y');
cout << gamecounter << " games || wins " << wincounter << endl;
float winpercentage = (float)wincounter / (float)gamecounter *100;
cout << "win rate: " << winpercentage << "%" << endl;
float lossrate = (1 - (float)wincounter / (float)gamecounter)*100;
cout << "loss rate: " << lossrate << "%" << endl;

}

