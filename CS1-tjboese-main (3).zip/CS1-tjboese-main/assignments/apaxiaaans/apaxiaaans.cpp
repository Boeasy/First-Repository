/*
Tyrel Boese
CSCI-111 HW 6 Strings

Algorithm Steps:
1. Read in file name in format: "apaxiaaans-00" "**input**" .in
2. create input stream, save input to vector
3. clean up the vector by deleting any repeating characters
4. output newly cleaned vector to output file in format: "apaxiaaans-00" "**input**" .ans
*/

#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <cassert>
using namespace std;


void readData(string&, string);
void cleanData(string&);
void writeData(string&, string);

void test();

int main(int argc, char * argv[]){
if (strcmp(argv[1], "test") == 0){
    test();

    return 0;}
string name= "";
int filenumber;
string fileName = "apaxiaaans-00";

cout << "Enter the input file number (between 1-3)" << endl;
cin >> filenumber;
fileName += std::to_string(filenumber);
string infileName = fileName + ".in";
string outfileName = fileName + ".ans";
//DEBUG:
// cout << "input file name is: " << infileName << endl;
// cout << "output file name is: " << outfileName << endl;

readData(name , infileName);
cleanData(name);
//DEBUG
cout << "name is: " << name << endl;
writeData(name , outfileName);

return 0;
}

void readData(string& name, string input){
    fstream fin;
    fin.open(input);
    string tmp;
    //DEBUG:
    cout << "input: " << input << endl;

    fin >> name;
    //DEBUG:
    cout << "name: " << name << endl;
    fin.close();
}

void writeData(string& name, string output){
    ofstream fout;
    fout.open(output);
    fout << name;
    fout.close();
}

void cleanData(string& name){
    //iterate through string -> delete duplicate characters
    //https://www.geeksforgeeks.org/string-at-in-cpp/ string at function
    string newname = "";

    newname += name.at(0);
    for (int i=1; i < name.length(); i++){
        if (name.at(i) != name.at(i-1)){
            //DEBUG:
            //cout << "name at i: " << name.at(i) << endl;
            newname += name.at(i);
        }
    }
    name = newname;
}

void test(){
    string test = "aaaaaaaaaaaaaaaaaaaaanthony";
    string test1 = "boooooooooooooooooooooooooooob";
    string test2= "cyynthiaaa";
    string test3 = "dooooooooorooooooootheeeeeeeaaaaaaaa";

    cleanData(test);
    cleanData(test1);
    cleanData(test2);
    cleanData(test3);

    assert(test == "anthony");
    assert(test1 == "bob");
    assert(test2 == "cynthia");
    assert(test3 == "dorothea");

    cout << "all tests passed!" << endl;
}