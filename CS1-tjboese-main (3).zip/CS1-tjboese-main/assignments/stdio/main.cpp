/*
Tyrel Boese
CSCI-111

Hangman program




*/

#include <iostream>

using namespace std;

int main() {
    string name;
    
    
    //2D array found on { geeksforgeeks.org/array-of-strings-in-cpp-5-different-ways-to-create/# }
    string hang[8]
            = {"     |-----------------", "     |/          |", "     |", "     |", "     |", "     |", "     |", "============"};

    // 2nd 2d array for other game states...
    string hung[8]
        = {"     |-----------------", "     |           |", "     |           O", "     |          ---", "     |           ^", "     |          / \\", "     |", "============"};


    cout << "Hey there, what's your name?" << endl;
    cin >> name;
    cout << "Hey, " << name << "!" << endl;
    cout << "The hangman game is under construction, maybe you'll get to play it in a few weeks..." << endl;
    cout << "This is what the various stages of the hangman game will look like..." << endl;

    // //for loop printing out the array
    //     for (int i = 0; i < 8; i++ ) {
    //     cout << hung[i] << endl;
    //     }

    // nested for loop to print out various game states....
        //

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 8; j++) {
                if (j > i) {
                    cout << hang[j] << endl;
                } else {
                    cout << hung[j] << endl;
                }

            }

        }


    return 0;
}
