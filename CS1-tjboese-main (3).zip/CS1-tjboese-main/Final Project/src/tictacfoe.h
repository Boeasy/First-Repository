//header for computer AI
#pragma once

#include <string>

namespace compAI {

    bool checkLine(char[9], int, int, char, int);
    bool win(char[9], char, char);
    bool blockwin(char[9], char, char);
    bool fork(char[9], char, char);
    bool blockfork(char[9], char, char);
    bool center(char[9], char, char);
    bool oppositecorner(char[9], char, char);
    bool emptycorner(char[9], char, char);
    bool emptyside(char[9], char, char);
    int randomsquare(char[9], char, char);

    void pcTurn(char[9], int, char, char);

}