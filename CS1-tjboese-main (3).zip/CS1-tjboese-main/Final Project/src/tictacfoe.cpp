//cpp of enemy AI

#include "game.h"
#include "format.h"
#include "tictacfoe.h"

namespace compAI {

    bool checkLine(char gameboard[9], int pos, int step, char token, int boxes){
        //instead of checking with token already at space, passes in token and searches for a pattern
        int pcCounter = 0;

        if ( gameboard[pos] == token) {pcCounter++;} //count up number of token in a line
        pos += step;
        if ( gameboard[pos] == token) {pcCounter++;} //count up number of token in a line
        pos += step;
        if ( gameboard[pos] == token) {pcCounter++;} //count up number of token in a line

        if (pcCounter == boxes) {return true;} //if it matches the threshhold set, return true
            return false;
        
    }
//-----------block-choosing-functions--------------------------------
    bool win(char gameboard[9], char token, char pctoken){
            for (int i=0; i<9; i++){
            if (gameboard[i] != pctoken && gameboard[i] != token){ //if board piece is empty...

                gameboard[i] = pctoken; // say this piece were taken by pc...

                //----------------check win function---------------------------
                for (int i = 0; i < 3; i++){ 
                //horizontals
                if (checkLine(gameboard, i*3, 1, pctoken, 3)) {
                    return true;}
                //verticals
                if (checkLine(gameboard, i, 3, pctoken, 3)) {
                    return true;}
            } //diagonals
                if (checkLine(gameboard, 0, 4, pctoken, 3) || checkLine(gameboard, 2, 2, pctoken, 3)){
                    return true;
                };
                //----------------check win function---------------------------

                }                
                gameboard[i] = ' '; //if the i value does not provide any wins, set it back to empty
                }
                return false; //if there are no forks in any of the 9 spaces, return false to go to next step.
            }            
    bool blockwin(char gameboard[9], char token, char pctoken){
           for (int i=0; i<9; i++){
            if (gameboard[i] != pctoken && gameboard[i] != token){ //if board piece is empty...

                gameboard[i] = pctoken; // say this piece were taken by pc...

                //----------------check win function---------------------------
                for (int i = 0; i < 3; i++){ 
                //horizontals
                if (checkLine(gameboard, i*3, 1, token, 3)) {
                    return true;}
                //verticals
                if (checkLine(gameboard, i, 3, token, 3)) {
                    return true;}
                //diagonals
                if (checkLine(gameboard, 0, 4, token, 3) || checkLine(gameboard, 2, 2, token, 3)){
                    return true;
                };
                //----------------check win function---------------------------

                }                
                gameboard[i] = ' '; //if the i value does not provide any wins, set it back to empty
                }
            }               
             return false; //if there are no forks in any of the 9 spaces, return false to go to next step.
    }
    bool fork(char gameboard[9], char token, char pctoken) {
        for (int i=0; i<9; i++){
            if (gameboard[i] != pctoken && gameboard[i] != token){ //if board piece is empty...

                gameboard[i] = pctoken; // say this piece were taken by pc...
                int temp = 0; //initialize a temp counter to 0
                //----------------check win function---------------------------
                for (int i = 0; i < 3; i++){ 
                //horizontals
                if (checkLine(gameboard, i*3, 1, pctoken, 2)) {
                    temp++;}
                //verticals
                if (checkLine(gameboard, i, 3, pctoken, 2)) {
                    temp++;}
            } //diagonals
                if (checkLine(gameboard, 0, 4, pctoken, 2) || checkLine(gameboard, 2, 2, pctoken, 2)){
                    temp++;
                };
                //----------------check win function---------------------------
                if (temp > 1){ //if this i value provides more than 1 win in the turn after, leave it selected
                     return true;
                }
                }
                gameboard[i] = ' '; //if the i value does not provide any forks, set it back to empty
            }
            return false; //if there are no forks in any of the 9 spaces, return false to go to next step.
        }
    bool blockfork(char gameboard[9], char token, char pctoken){
        for (int i=0; i<9; i++){
            if (gameboard[i] != pctoken && gameboard[i] != token){ //if board piece is empty...

                gameboard[i] = token; // say this piece were taken by player...
                int temp = 0; //initialize a temp counter to 0
                //----------------check win function---------------------------
                for (int i = 0; i < 3; i++){ 
                //horizontals
                if (checkLine(gameboard, i*3, 1, token, 2)) {
                    temp++;}
                //verticals
                if (checkLine(gameboard, i, 3, token, 2)) {
                    temp++;}
            } //diagonals
                if (checkLine(gameboard, 0, 4, token, 2) || checkLine(gameboard, 2, 2, token, 2)){
                    temp++;
                };
                //----------------check win function---------------------------
                if (temp > 1){ //if this i value provides more than 1 win in the turn after, leave it selected
                     return true;
                }
                }
                gameboard[i] = ' '; //if the i value does not provide any forks, set it back to empty
            }
            return false; //if there are no forks in any of the 9 spaces, return false to go to next step.
        }
    bool center(char gameboard[9], char token, char pctoken){
        if (gameboard[4] != token && gameboard[4] != pctoken){ //if empty 
            gameboard[4] = pctoken; //choose center square
            return true;
        }
        return false; //return false to go to next
    }
    bool oppositecorner(char gameboard[9], char token, char pctoken){
        //corners are 0,2,6,8
        if ((gameboard[0] != token && gameboard[0] != pctoken)&&(gameboard[8] == token || gameboard[8] == pctoken)){
            //if 0 empty and 8 taken, pick 0
            gameboard[0] = pctoken;
            return true;
        }
        if ((gameboard[2] != token && gameboard[2] != pctoken)&&(gameboard[6] == token || gameboard[6] == pctoken)){
            //if 2 empty and 6 taken, pick 2
            gameboard[2] = pctoken;
            return true;
        }
        if ((gameboard[6] != token && gameboard[6] != pctoken)&&(gameboard[2] == token || gameboard[2] == pctoken)){
            //if 6 empty and 2 taken, pick 6
            gameboard[6] = pctoken;
            return true;
        }
        if (gameboard[8] != token && gameboard[8] != pctoken){
            //if 8 empty, pick 8
            gameboard[8] = pctoken;
            return true;
        }
        return false;
    }
    bool emptyside(char gameboard[9], char token, char pctoken){
        //empty middle side pieces are 1,3,5,7
        //not sure if it will ever get this far down the list...

        if (gameboard[1] != token && gameboard[1] != pctoken){
            //if 8 empty, pick 8
            gameboard[1] = pctoken;
            return true;
        }        
        if (gameboard[3] != token && gameboard[3] != pctoken){
            //if 8 empty, pick 8
            gameboard[3] = pctoken;
            return true;
        }        
        if (gameboard[5] != token && gameboard[5] != pctoken){
            //if 8 empty, pick 8
            gameboard[5] = pctoken;
            return true;
        }        
        if (gameboard[7] != token && gameboard[7] != pctoken){
            //if 8 empty, pick 8
            gameboard[7] = pctoken;
            return true;
        }
        return false;
    }
    int randomsquare(){
        char empty = ' ';
        int n2 = 0; // initialize temp rand variable at 0
        do {
        n2 = rand() % 9; //random mod 9 for random variable between 0 and 8
        } while (!game::checksquare(n2, empty)); // keep randoming until it finds a blank square
    return n2; //returns value of that blank square
    }
//-----------block-choosing-functions--------------------------------

//-------------enemy-computer-logic-----------------------------------
    void pcTurn(char gameboard[9], int diff, char pctoken, char token){
            int n1;
            switch (diff){

                case 1 ://diff 1 // will win if has two in a row
                    if (win(gameboard, token, pctoken)){ 
                        break;}     //if a win is found break, otherwise goes down the list
                    if (blockwin(gameboard, token, pctoken)) {
                        break;} //if block found, break
                        n1 = randomsquare();
                    gameboard[n1] = pctoken; // places token at random square that is blank

                        break;

                case 2 ://diff 2 will block wins and take their own wins
                    if (win(gameboard, token, pctoken)){ 
                        break; //if a win is found break, otherwise goes down the list
                    } 
                    if (blockwin(gameboard, token, pctoken)) 
                    {
                        break; //if block found, break
                    } 

                        n1 = randomsquare();
                    gameboard[n1] = pctoken; // places token at random square that is blank
                        break;

                case 3 : //diff 3 will find forks
                    if (win(gameboard, token, pctoken)){ 
                        break; //if a win is found break, otherwise goes down the list
                    } 
                    if (blockwin(gameboard, token, pctoken)) 
                    {
                        break; //if block found, break
                    } 
                    if (fork(gameboard, token, pctoken)) {
                        break; //if fork found, break
                    }

                        n1 = randomsquare();
                    gameboard[n1] = pctoken; // places token at random square that is blank
                        break;

                case 4 :  //diff 4 blocks forks
                    if (win(gameboard, token, pctoken)){ 
                        break; //if a win is found break, otherwise goes down the list
                    } if (blockwin(gameboard, token, pctoken)) {
                        break; //if block found, break
                    } if (fork(gameboard, token, pctoken)) {
                        break; //if fork found, break
                    } 
                    if (blockfork(gameboard, token, pctoken)) {
                        break; //if enemy fork found, break
                    }

                        n1 = randomsquare();
                    gameboard[n1] = pctoken; // places token at random square that is blank
                        break;      
                    
                case 5 ://diff 5 makes almost no mistakes
                    if (win(gameboard, token, pctoken)){ 
                        break; //if a win is found break, otherwise goes down the list
                    } if (blockwin(gameboard, token, pctoken)) {
                        break; //if block found, break
                    } if (fork(gameboard, token, pctoken)) {
                        break; //if fork found, break
                    } 
                    if (blockfork(gameboard, token, pctoken)) {
                        break; //if enemy fork found, break
                    }
                    if (center(gameboard, token, pctoken)){
                        break; //if enter not taken, take it, break
                    }     

                        n1 = randomsquare();
                    gameboard[n1] = pctoken; // places token at random square that is blank
                        break;

                case 6://diff 6 plays a wikipedia perfect game
                    if (win(gameboard, token, pctoken)){ 
                        break; //if a win is found break, otherwise goes down the list
                    } if (blockwin(gameboard, token, pctoken)) {
                        break; //if block found, break
                    } if (fork(gameboard, token, pctoken)) {
                        break; //if fork found, break
                    } 
                    if (blockfork(gameboard, token, pctoken)) {
                        break; //if enemy fork found, break
                    }
                    if (center(gameboard, token, pctoken)){
                        break; //if enter not taken, take it, break
                    } 
                    if (oppositecorner(gameboard, token, pctoken)){
                        break; // if corner opposite an occupied corner is found, or an empty corner otherwise, break
                    }
                    if (emptyside(gameboard, token, pctoken)){ 
                        break; // if an empty side piece is found, break
                    }

                        n1 = randomsquare();
                    gameboard[n1] = pctoken; // places token at random square that is blank
                        break;

                default: //difficulty 0: all randoms 

                        n1 = randomsquare();
                    gameboard[n1] = pctoken; // places token at random square that is blank
                        break;   
            }

        }
//-------------enemy-computer-logic-----------------------------------

     }
