//format functions

#include <string>
#include <iostream>
#include <iomanip>
#include "format.h"

namespace format {
    // format funtions and ints here....

            void printBoard(char board[9]){ //will have to change this later to make other board sizes work...
                const char separator = ' ';
                const char newline = '-';
                std::cout << std::setw(9) << std::setfill(separator) << board[0];
                std::cout << std::setw(9) << std::setfill(separator) << "|";
                std::cout << std::setw(9) << std::setfill(separator) << board[1];
                std::cout << std::setw(9) << std::setfill(separator) << "|";
                std::cout << std::setw(9) << std::setfill(separator) << board[2];
                std::cout << std::setw(45) << std::setfill(newline) << newline << std::endl;
                std::cout << std::setw(9) << std::setfill(separator) << board[3];
                std::cout << std::setw(9) << std::setfill(separator) << "|";
                std::cout << std::setw(9) << std::setfill(separator) << board[4];
                std::cout << std::setw(9) << std::setfill(separator) << "|";
                std::cout << std::setw(9) << std::setfill(separator) << board[5];
                std::cout << std::setw(45) << std::setfill(newline) << newline << std::endl;
                std::cout << std::setw(9) << std::setfill(separator) << board[6];
                std::cout << std::setw(9) << std::setfill(separator) << "|";
                std::cout << std::setw(9) << std::setfill(separator) << board[7];
                std::cout << std::setw(9) << std::setfill(separator) << "|";
                std::cout << std::setw(9) << std::setfill(separator) << board[8];
                std::cout << std::setw(45) << std::setfill(newline) << newline << std::endl;

            } 

            void mainMenu(){  //switch statement takes you to option
                const char separator = '.';

                std::cout << std::setw(16) << std::setfill(separator) << " 1 - Choose Player " << std::endl;
                std::cout << std::setw(16) << std::setfill(separator) << " 2 - Change Difficulty " << std::endl;
                std::cout << std::setw(16) << std::setfill(separator) << " 3 - Leaderboard " << std::endl;
                std::cout << std::setw(16) << std::setfill(separator) << " 4 - Player Stats " << std::endl;
                std::cout << std::setw(16) << std::setfill(separator) << " 5 - Start Game " << std::endl;
                std::cout << std::setw(16) << std::setfill(separator) << " 6 - Exit " << std::endl;
            }; 

            }