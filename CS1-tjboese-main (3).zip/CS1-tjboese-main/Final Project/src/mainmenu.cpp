//mainmenu functions

#include <string> // place holder
#include <iostream>
#include "mainmenu.h"
#include "format.h"
#include "game.h"

namespace mainMenu {
    // mainMenu funtions and vars here....

    void option(){
        int input;
        bool endgame;
        endgame = false;
        std::string player;
        int* difficulty = new int;


        do {
        format::mainMenu();
        std::cin >> input;

        switch (input){
            case 1: // Choose Player
            choosePlayer(player);
            break;        
            case 2: // Change Difficulty
            *difficulty = changeDifficulty();
            break;
            case 3: // Leaderboard
            leaderBoard();
            break;
            case 4: // Player Stats
            playerStats();
            break;
            case 5: // Start Game
            game::gameStart();
            break;
            case 6: // Exit
                endgame = quit();
                break;
            break;
            default: // Print Menu Again
            format::mainMenu();
            break;
        }
        } while (!endgame);

        delete difficulty;
    }

    void choosePlayer(std::string& player){
        /*
        prompt for username - getline(cin, playername)
        send back to menu
        */
       std::getline(std::cin, player);
    }

    int changeDifficulty(){
        int temp;
        /*
        cout 'current difficulty'
        cout difficulty levels 1-9 + explanations?
        do while loop (until valid input)
        cin >> difficulty
        cout << difficulty level is "_"

        send back to menu...
        */

       do {
        std::cout<< "Enter the difficulty level (1-6)" << std::endl;
        std::cin >> temp;
       } while (temp != 0 && temp != 1 && temp != 2 &&
       temp != 3 && temp != 4 && temp != 5 && temp != 6 );
        return temp;
    }

    void leaderBoard(){

        // format::printScores();
        /*
        print leaderboard
        wait for user input

        go back to menu
        */
    }

    void playerStats(){
        /*
        print current player stats

        wait for user input

        go back to menu
        
        */
    }

    bool quit(){
        /*
        exit program...
        */
       char input;
       std::cout << "Exit? (Y/N)" << std::endl;
       std::cin >> input;

       if (input != 'N'){
        return true;
       }
        return false;
    }

}