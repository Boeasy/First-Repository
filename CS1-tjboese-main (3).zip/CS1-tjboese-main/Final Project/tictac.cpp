/*
Tyrel Boese
CS-1 Final Project
Tic-Tac-Toe
*/

#include <iostream>
#include <iomanip>
#include <cassert>
#include <cmath>

#include "src/format.h"
#include "src/game.h"
#include "src/mainmenu.h"

//#include <SFML/Graphics.hpp> (if time permits...)

using namespace std;

int main(int argc, char * argv[]){

    cout << "Welcome to my Tic Tac Toe game!" << endl;

    format::mainMenu(); //prints main menu
    mainMenu::option(); //selects function based on user input

    return 0;
}

