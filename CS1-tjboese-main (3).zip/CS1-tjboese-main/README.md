# CSCI-111_TJBoese
CSCI-111 repo

# csci-111 Tyrel Boese

## A  github repo demonstrating how to turn in assignments and labs

| Name | Value |
|:---|:---|
| **Course** | CSCI111 - CS1: Foundations of Computer Science |
| **Section** | 1 |
| **Semester** | Fall 2023 |
| **Student** | Tyrel Boese |
| **Mav Username**            | tjboese |
| **GitHub Username**         | Boeasy |
| **Repository**          | https://github.com/Boeasy/CS1-tjboese/ |

## Assignments

### Assignment #1

| Name | Value |
| :--- | :--- |
| Name | Hello World |
| Description | A basic hello world program |
| Due Date | Sept 8th 2023 |
| Status | Done |
| Location | https://github.com/Boeasy/CS1-tjboese/tree/main/assignments/hellocs |
| Self Grade | 100/100 |
| Notes | says hello world |

### Assignment #2

| Name | Value |
| :--- | :--- |
| Name | ---- |
| Description |  |
| Due Date | - |
| Status | Complete |
| Location | |
| Self Grade | /100|
| Notes | |

## Homework

### Homework #1

| Name | Stdio |
| :--- | :--- |
| Name | Hangman |
| Description | basic hang man game |
| Due Date | Sept 11th 2023 |
| Status | Done |
| Location | https://github.com/Boeasy/CS1-tjboese/tree/main/assignments/stdio |
| Self Grade | 100/100 |
| Notes | shows game states using nested for loop... no game logic yet |

### Homework #2

| Name | Triangles|
| :--- | :--- |
| Name | Triangles |
| Description | Calculating Triangle Values based on Input |
| Due Date | Sept 25th 2023 |
| Status | Done |
| Location | https://github.com/Boeasy/CS1-tjboese/tree/main/assignments/Triangle |
| Self Grade | 100/100 |
| Notes | Works as Intended |

## Labs

### Lab #1

| Name | Value |
| :--- | :--- |
| Name | 1 ASCII art |
| Description | drawing ascii art using exit characters and cout |
| Due Date | Sept 8th 2023 |
| Status | complete |
| Location | (https://github.com/Boeasy/CS1-tjboese/tree/14f2a065532299742974e5bed3f396427c05db53/LABS/ascii)) |
| Self Grade | 100/100 |
| Notes | works as intended|

### Lab #2

| Name | Value |
| :--- | :--- |
| Name | Circles |
| Description |  This program prompts the user to enter the radius of a circle.
 It then calculates and displays its area and circumference. |
| Due Date | Sept 19th 2023 |
| Status | complete |
| Location | (https://github.com/Boeasy/CS1-tjboese/tree/14f2a065532299742974e5bed3f396427c05db53/LABS/Circle) |
| Self Grade | 100/100 |
| Notes | Calculates area and circumference|

### Lab #2

| Name | Value |
| :--- | :--- |
| Name | Functions |
| Description |  Prompts user for two points formated (x,y)
 It then calculates and displays the distance between them |
| Due Date | Oct 3rd 2023 |
| Status | complete |
| Location | (https://github.com/Boeasy/CS1-tjboese/tree/14f2a065532299742974e5bed3f396427c05db53/LABS/Functions) |
| Self Grade | 100/100 |
| Notes | Works as Intended, can get stuck in loop if typing in wrong format or different input than Y/N|


## References

1. [How to turn in assignments on GitHub](https://docs.google.com/document/d/16mixtVA-dePbWidBzI3JXNW4kFhRyT7XsJgL6GtGvGA/edit?usp=sharing)
2. [Git Started](https://docs.google.com/document/d/1M0YeBfFPy5YPpfX7312R9-IldjagimvEma_YhgeLPcw/edit#heading=h.ssqvh5gmotj4)
3. [Markdown Syntax](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet)
4. 
