/*
    Loops Lab
    Updated By: Tyrel Boese
    CSCI 111
    Date: 10-26-23

    Program prints geometric shapes of given height with * using loops
*/

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;


void printTriangle(int height) {
    //Function takes height as an argument to print the triangle
    //of that height with *
    int row = 1;
    // row
    while (row <= height) {
        // column
        for(int col = 1; col<=row; col++)
            cout << "* ";
        row += 1;
        cout << endl;
    }
}


void printFlippedTriangle(int height) {
    /* 
    Implement the function that takes height as an argument
    and prints a triangle with * of given height.
    Triangle of height 5, e.g., should look like the following.
    * * * * *
    * * * *
    * * *
    * *
    *
    
    */
    // FIXME3 ... #FIXED
    for (int i=0; i < height; i++){
        for (int j=1; j < height+1; j++){
            if (j > i){
                cout << "* ";
            } if (j == i){
                cout << endl;
            }

        }

    }
            
}


/*  
FIXME4 #FIXED
Design and implement a function that takes an integer as height and
prints square of the given height with *.
Square of height 5, e.g., would look like the following.

*  *  *  *  *  
*  *  *  *  *   
*  *  *  *  *   
*  *  *  *  *   
*  *  *  *  *   

*/

void printSquare(int height) {

for (int i=0; i < height; i++){
    cout << endl;
        for (int j=0; j < height; j++){
                cout << "* ";
            }
            }

        }

// function clears the screen system call
// NOTE: system call is not a security best pracice!
void clearScreen() {
    // use "cls" in windows and "clear" command in Mac and Linux
    #ifdef _WIN32
        system("clS");
    #else
        system("clear");
    #endif
}

int main(int argc, char* argv[]) {
    // FIXME5 add a loop to make the program to continue to run until the user wants to quit #FIXED
    // FIXME6 call clearScreen function to clear the screen for each round of the loop #FIXED
    int height;
    char cont='y';
    int selector;

    do {
    clearScreen();
    cout << "Program prints geometric shapes of given height with *\n";
    cout << "Please enter the height of the shape: ";
    cin >> height;

    cout << "which shape would you like to print?" << endl;
    cout << "1 - Triangle" << endl << "2 - Upside-down Triangle " << endl << "3 - Square" << endl;
    cin >> selector; 
    switch(selector){
        case 1:
    // call printTriangle function passing user entered height
    printTriangle(height);
        goto keep_going;

        case 2:
    // FIXME7 
    // Call printFlippedTriangle passing proper argument #FIXED
    // Manually test the function
        printFlippedTriangle(height);        
            goto keep_going;

        case 3:
    // FIXME6
    // Call the function defined in FIXME4 passing proper argument #FIXED
    // Manually test the function
    printSquare(height);
        goto keep_going;


    // FIXME9
    // prompt user to enter y/Y to continue anything else to quit #FIXED
    keep_going:
    cout << endl << "enter y/Y to continue, or anything else to quit" << endl;
    cin >> cont;
    }
    // FIXME10
    // Use conditional statements to break the loop or continue the loop
    } while (cont == 'y');
    return 0;
}