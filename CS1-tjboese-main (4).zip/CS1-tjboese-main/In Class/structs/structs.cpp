/*
Name Tyrel Boese

Structures 

*/

#include <iostream>
#include <string>

using namespace std;


struct Point {
    int x;
    int y;
    int z;
};

int main(int argc, char *argv[]) {
    //int x1, x2, y1, y2;
    //int x[10];
    //int y[10];

    Point point1;
    Point point2;

    point1.x = 0;
    point1.y = 0;

    point2.x = 1;
    point2.y = 1;

    cout << "&point1: " << &point1 << endl;
    cout << "&point2: " << &point2 << endl;

    

}