/*
Name: Tyrel Boese

Functions  
*/

#include <iostream>
#include <cmath>

using namespace std;

int main() {

int number1;

cout << "Please enter a number: ";
cin >> number1;

cout << "The abs of your number is : " << abs(number1) << endl;
return 0;

}