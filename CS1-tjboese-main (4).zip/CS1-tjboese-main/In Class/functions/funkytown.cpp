/*
Name: Tyrel Boese

Functions!!!!!!
*/

#include <iostream>
#include <string>

using namespace std;

// void sayHello() {
//     cout << "Hello World" << endl;
// }

// int main() {
//     sayHello();
//     return 0;
// }

void addNums(float n1, float n2, float &ans) {
    cout << "DEBUG: func ans: " << &ans << endl;
    ans = n1+ n2;


}

int main() {
    float num1, num2;
    float answer = 0;

    cout << "DEBUG: main answer: " << &answer << endl;
    cout << "Please enter two whole nubmers separated by a space" << endl;
    cin >> num1 >> num2;

    addNums(num1, num2, answer);
    cout << answer << endl;

}