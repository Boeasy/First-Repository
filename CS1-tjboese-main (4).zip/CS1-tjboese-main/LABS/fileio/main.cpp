/*
    CS1 - File IO Lab

    Updated by: Tyrel Boese
    Date: 11-26-23 

    The program reads numbers from a file and finds statistical values from those numbers.
    Lab demonstrates the file io and vector application. 
    Statistical value's definitions for mean, median, mode, etc. can be found here: https://www.purplemath.com/modules/meanmode.htm
*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <cassert>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

const float EPSILON = 1e-4; //accuracy upto 4 decimal points

// function prototypes
void readData(vector<int> &, const string);
int findMax(const vector<int> &);
int findMin(const vector<int> &);
float findMean(const vector<int> &); // average
int findRange(const vector<int> &);
float findMedian(vector<int>);
// bonus implement findMode function
int findMode(const vector<int> &);

void writeData(const vector<int> & numbers);
void test();

int main(int argc, char* argv[]) {
    if (argc == 2 && string(argv[1]) == "test") {
        test();
        return 0;
    }
    vector<int> numbers;
    string inFile;
    cout << "Enter input file name: ";
    getline(cin, inFile);
    //DEBUG:
    cout << "your input file name is " << inFile << endl;
    readData(numbers, inFile);
    writeData(numbers);
    cout << "All done. Enter to exit...";
    cin.get();
    return 0;
}

void readData(vector<int> & numbers, const string inputFileName) {
    // FIXME3: Open inputFileName for reading data #FIXED
    // read the data until eof marker and store each num into numbers vector
    int line;
    fstream input;
    input.open(inputFileName);
    while (!input.eof()){
    input >> line;
    numbers.push_back(line);
    }
    input.close();
}


void writeData(const vector<int> & numbers) {
    string outputFileName;
    // FIXME4 #FIXED
    /*
    Algorithm steps:
    1. Prompt user to enter output file name
    2. Store and use the file name to open the file in write mode
    3. Write output as shown in output.txt file with proper formatting using iomanip
    */
   cout << "enter output file name: " << endl;
   cin >> outputFileName;
   ofstream Outputfile;
   Outputfile.open(outputFileName);
   // https://stackoverflow.com/questions/6406356/how-to-write-vector-values-to-a-file
    for (const auto &e : numbers) Outputfile << e << endl;


   Outputfile.close();

}

int findMax(const vector<int> & nums) {
    int max = nums[0];
    for(int n: nums)
        max = (n>max) ? n : max;
    return max;
}

int findMin(const vector<int> & nums) {
    // FIXME5 - implement function to find and return min value from nums vector #FIXED
    int min = nums[0];
    for(int n: nums)
        min = (n<min) ? n : min;
    return min;
} 

float findMean(const vector<int> & nums) {
    // same as average
    long long int sum = 0;
    for(int n: nums)
        sum += n;
    return sum/float(nums.size());
}

int findRange(const vector<int> & nums) {
    // FIXME6 - implement function that finds and returns the range value #FIXED
    // range = max - min
    //call max, call min, subtract values, return...
    int tmp1;
    int tmp2;
    int range;

    tmp1 = findMax(nums);
    tmp2 = findMin(nums);

    range = tmp1 - tmp2;


    return range;
}

float findMedian(vector<int> nums) {
    sort(nums.begin(), nums.end());
    float median;
    if (nums.size() % 2 == 0) {  // even set
        median = (nums[nums.size()/2] + nums[nums.size()/2-1])/float(2);
    } else { // odd set
        median = nums[nums.size()/2];
    }
    return median;
}

int findMode(const vector<int> &nums){
    int mode=0;
    int tempmode=0;
    int tempcount;
    int count=0;

    for (int j=0; j < nums.size(); j++){
        tempmode = nums[j]; //save the current number in the array...
        tempcount = 0; //initialize the temporary counter at 0;
        for (int i=0; i < nums.size();i++){
            if (tempmode == nums[i]){
                tempcount++;
            }
        }
        if (tempcount >= count){
            mode = tempmode;
            count = tempcount;
        }

        }
        //will not work with multimodal sets... possibly vector?





    return mode;
}



void test() {
    
    vector<int> numbers = {100, 10, 5, 0, -99, 10, 99};
    //cout << findMin(numbers) << " , " << findMax(numbers)<< " , " << findRange(numbers) << " , " << findMode(numbers) << "min, max, range, mode" << endl;
    assert(fabs(findMean(numbers)-17.857142) <= EPSILON );
    assert(findMax(numbers) == 100);
    assert(findMedian(numbers) == 10);
    vector<int> numbers1 = {10, 10, 10, 0, -10, -10};
    assert(fabs(findMean(numbers1) -1.6667) <= EPSILON  );
    assert(findMax(numbers1) == 10);
    assert(findMedian(numbers1) == 5);
    vector<int> numbers2 = {100, 10, 5, 0, -99, 10, 99};
    assert(findMin(numbers2) == -99);
    assert(findMode(numbers2) == 10);
    vector<int> numbers3 = {10, 10, 10, 0, -10, -10};
    assert(fabs(findRange(numbers3)) == 20  );
    assert(findMin(numbers3) == -10);
    assert(findMode(numbers3) == 10);
    // FIXME7: Write at least two test cases for other functions #FIXED


    cerr << "all test cases passed!\n";
}


