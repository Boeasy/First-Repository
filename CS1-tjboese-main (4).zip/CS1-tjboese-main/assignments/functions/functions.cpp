/*
Tyrel Boese
Functions (HW3)

Write a C++ program that performs some arithmetic operations on two given numbers 
(entered by user) along with the following requirements.

*/

#include <iostream>
#include <cmath>
#include <cassert>

using namespace std;

int add(int, int);
float add(float, float);

int subtract(int, int);
float subtract(float, float);

int multiply(int, int);
float multiply(float, float);

int divide(int, int);
float divide(float, float);

float power(float, float);
int power(int, int);

float root(float);
int rootA(int, int);
int rootB(int, int);

int mod(int, int);
float mod(float, float);

float largest(float, float);
int largest(int, int);

void test();

int add(int num1, int num2) {

    int sum = num1 + num2;
    return sum;
}
float add(float num1, float num2) {

    int sum = num1 + num2;
    return sum;
}
int subtract(int num1, int num2) {
    int diff = num1 - num2;
    return diff;
}
float subtract(float num1, float num2) {
    int diff = num1 - num2;
    return diff;
}
int multiply(int num1, int num2) {
    int product = num1 * num2;
    return product;
}
float multiply(float num1, float num2) {
    int product = num1 * num2;
    return product;
}
int divide(int num1, int num2) {
    int quotient = num1/num2;
    return quotient;
}
float divide(float num1, float num2) {
    float quotient = num1/num2;
    return quotient;
}
float power(float num1, float num2){
    float result = pow(num1, num2);
    return result;
}
int power(int num1, int num2){
    float result = pow(num1, num2);
    return result;

}
float root(float num1) {
    float result = sqrt(num1);
    return result;
}
int rootA(int num1, int num2) {
    float result = sqrt(num1);
    return result;
}
int rootB(int num1, int num2) {
    float result = sqrt(num2);
    return result;
}
int mod(int num1, int num2) {
   int mod = num1 % num2;
   return mod;
}
float mod(float num1, float num2) {
   int mod = fmod(num1, num2);
   return mod;
}
float largest(float num1, float num2) {
    int num3 = num1 - num2;
    if (num3 >= 0){
        return num1;
    } else if (num3 < 0) {
        return num2;
    }
    else return 0;
}
int largest(int num1, int num2) {
    int num3 = num1 - num2;
    if (num3 >= 0){
        return num1;
    } else if (num3 < 0) {
        return num2;
    }
    else return 0;
}

// function overloading to work with ints or floats


int main(int argc, char * argv[] ) {
if (strcmp(argv[1], "test") == 0){
    test();

    return 0;}
float num1, num2;

cout << "Enter two numbers separated by a space" << endl;
cin >> num1 >> num2;

cout << "Addition: " << add(num1, num2) << endl;
cout << "Subtration: " << subtract(num1, num2) << endl;
cout << "Multiplication: " << multiply(num1, num2) << endl;
cout << "Division: " << divide(num1, num2) << endl;
cout << "A ^ B: " << power(num1, num2) << endl;
cout << "Sqrt of A: " << root(num1) << endl;
cout << "Sqrt of B: " << root(num2) << endl;
cout << "A % B : " << mod(num1, num2) << endl;
cout << "The Larger Number is: " << largest(num1, num2) << endl;


return 0;
}
//https://stackoverflow.com/questions/252748/how-can-i-use-an-array-of-function-pointers found solution here
void test() {
int counter = 0;
int (*p[8]) (int num1, int num2) = {add, subtract, multiply, divide, rootA, rootB, mod, largest};

int doItwork[][3]=
    {
    {1,2,3}, //add
    {2,4,6},//add
    {6,4,2},//sub
    {3,2,1},//sub
    {1,2,2},//mul
    {2,4,8},//mul
    {8,4,2},//div
    {2,1,2},//div
    {9,0,3}, //roota
    {81,0,9}, //roota
    {0,9,3}, //rootb
    {0,81,9}, //rootb
    {7,5,2}, //mod
    {3,2,1}, //mod
    {1,2,2}, //larger
    {8,18,18} //larger
    };
       
        for (int i=0; i<16; i++)
        {
        
        assert( (*p[counter])(doItwork[i][0], doItwork[i][1]) == doItwork[i][2]); //.. c assert ..
        // cout << doItwork[i][0] << endl; DEBUG
        // cout << doItwork[i][1] << endl;DEBUG
        // cout << doItwork[i][2] << endl;DEBUG
        // cout << "counter: " << counter << endl;DEBUG

        if (i % 2 == 1)
         {
            counter++;
            }             

        }
cerr << "all tests passed..." << endl;


}

//ptr = p;
// *(ptr+i) - dereference pointer, equivalent to p[counter]()...