/*
Tyrel Boese
Conditonals (HW4)

Write a command line interface (CLI) based menu-driven C++ program that computes certain values such as sum, product, max, 
min, average, oddity of any 5 given numbers along with the following requirements. 

*/

#include <iostream>
#include <cmath>
#include <cassert>

using namespace std;
float findSum(float inArr[]);
float findProduct(float inArr[]);
float findAvg(float inArr[]);
float findLarger(float inArr[]);
float findSmaller(float inArr[]);
float findFloor(float inArr[]);

float inArr[]={1,2,3,4,5};
float findSum(float inArr[]){
    float sum = 0;
    for (int i=0; i < 5; i++ ){
        sum = sum + inArr[i];
    }
    return sum;
}
float findProduct(float inArr[]){
    float prod = 1;
    for (int i=0; i < 5; i++){
        prod = prod * inArr[i];
    }
    return prod;
}
float findAvg(float inArr[]){
    float avg = findSum(inArr) / 5;
    return avg;
}
float findLarger(float inArr[]) {
    bool sorted = true;
    
    for (size_t i=0; i<5; i++){
        sorted = true;
        for (size_t j=0; j<5-i; j++){
            if(inArr[i] > inArr[i+1]){
                int tmp = inArr[i+1];
                inArr[i+1] = inArr[i]; 
                inArr[i] = tmp;
                sorted = false;
            } if(sorted){
                break;
            }
        }

    }
    return inArr[4];
}
float findSmaller(float inArrp[]){
bool sorted = true;
    
    for (size_t i=0; i<5; i++){
        sorted = true;
        for (size_t j=0; j<5-i; j++){
            if(inArr[i] > inArr[i+1]){
                int tmp = inArr[i+1];
                inArr[i+1] = inArr[i]; 
                inArr[i] = tmp;
                sorted = false;
            } if(sorted){
                break;
            }
        }

    }
    return inArr[0];
}
float findFloor(float inArr[]) {
float sum = findSum(inArr);
int floInt = floor(sum);
if (floInt > 0) {
    return 1;
} else if (floInt < 0) {
    return -1;
} 
return 0;
}
void test() {

inArr[0]=5;
inArr[1]=5;
inArr[2]=5;
inArr[3]=5;
inArr[4]=5;

assert(findSum(inArr)== 25 );
assert(findProduct(inArr)== 3125 );
assert(findAvg(inArr)== 5 );
assert(findLarger(inArr)== 25 );
assert(findSmaller(inArr)== 25 );
assert(findFloor(inArr)== 25 );

inArr[0]=5;
inArr[1]=5;
inArr[2]=5;
inArr[3]=5;
inArr[4]=5;

assert(findSum(inArr)== 25 );
assert(findProduct(inArr)== 25 );
assert(findAvg(inArr)== 25 );
assert(findLarger(inArr)== 25 );
assert(findSmaller(inArr)== 25 );
assert(findFloor(inArr)== 25 );

inArr[0]=1;
inArr[1]=5;
inArr[2]=1;
inArr[3]=5;
inArr[4]=1;

assert(findSum(inArr)== 25 );
assert(findProduct(inArr)== 25 );
assert(findAvg(inArr)== 25 );
assert(findLarger(inArr)== 25 );
assert(findSmaller(inArr)== 25 );
assert(findFloor(inArr)== 25 );

inArr[0]=10;
inArr[1]=-10;
inArr[2]=-7;
inArr[3]=72;
inArr[4]=99;

assert(findSum(inArr)== 25 );
assert(findProduct(inArr)== 25 );
assert(findAvg(inArr)== 25 );
assert(findLarger(inArr)== 25 );
assert(findSmaller(inArr)== 25 );
assert(findFloor(inArr)== 25 );

cerr << "all tests passed..." << endl;
}

void getNumbers(){
cout << "Enter five numbers separated by a space" << endl;
for (int i=0; i<5; i++){
cin >> inArr[i];}
}

int main(int argc, char * argv[] ) {
 if (strcmp(argv[1], "test") == 0)
 {
    test();

    return 0;
}
bool keepGoing = true;
string name;
cout << "Please Enter Name: " << endl;
cin >> name;

cout << "Hello, " << name << ", and welcome to my calculator program!" << endl;

//start loop here... do while loop?
do {
    cout << "Enter 5 numbers and then select an operation:" << endl;

    for (size_t i=0; i < 5; i++) {
        cin >> inArr[i];
    }
    cout << "To find the Sum of these numbers enter '1'" << endl;
    cout << "To find the Product of these numbers enter '2'" << endl;
    cout << "To find the Average of these numbers enter '3'" << endl;
    cout << "To find the Largest of these numbers enter '4'" << endl;
    cout << "To find the Smallest of these numbers enter '5'" << endl;
    int input = 0;
    cin >> input;
    switch(input){
            case 1:
            cout << "The sum of the numbers you entered is: " << findSum(inArr) << endl;
                goto exit_loop ;
            case 2:
            cout << "The product of the numbers you entered is: " << findProduct(inArr) << endl;
                goto exit_loop ;
            case 3:
            cout << "The average of the numbers you entered is: " << findAvg(inArr) << endl;
                goto exit_loop ;
            case 4:
            cout << "The largest of the numbers you entered is: " << findLarger(inArr) << endl;
                goto exit_loop ;
            case 5:
            cout << "The smallest of the numbers you entered is: " << findSmaller(inArr) << endl;
                goto exit_loop ;
        default:
                goto exit_loop ;

        exit_loop:
        cout << "Try Another set?" << endl << "Enter 'y' to repeat" << endl;
        char temp;
        cin >> temp;
        if (temp != 'y'){
            keepGoing = false;
        }
        }
}
while (keepGoing == true );

}
// void test() {
// int counter = 0;
// int (*p[8]) (int num1, int num2) = {add, subtract, multiply, divide, rootA, rootB, mod, largest};

// int doItwork[][3]= 
//     {
//     {1,2,3}, //add
//     {2,4,6},//add
//     {6,4,2},//sub
//     {3,2,1},//sub
//     {1,2,2},//mul
//     {2,4,8},//mul
//     {8,4,2},//div
//     {2,1,2},//div
//     {9,0,3}, //roota
//     {81,0,9}, //roota
//     {0,9,3}, //rootb
//     {0,81,9}, //rootb
//     {7,5,2}, //mod
//     {3,2,1}, //mod
//     {1,2,2}, //larger
//     {8,18,18} //larger
//     };
       
//         for (int i=0; i<16; i++)
//         {
        
//         assert( (*p[counter])(doItwork[i][0], doItwork[i][1]) == doItwork[i][2]); //.. c assert ..
//         // cout << doItwork[i][0] << endl; DEBUG
//         // cout << doItwork[i][1] << endl;DEBUG
//         // cout << doItwork[i][2] << endl;DEBUG
//         // cout << "counter: " << counter << endl;DEBUG

//         if (i % 2 == 1)
//          {
//             counter++;
//             }             

//         }
// cerr << "all tests passed..." << endl;
//}