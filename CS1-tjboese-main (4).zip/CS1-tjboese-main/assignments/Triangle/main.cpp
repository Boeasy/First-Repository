/*
Tyrel Boese
Assignment: Triangles
CSCI-111

Design and implement an algorithm using C++ that finds the perimeter and area of a given triangle

Given three sides of a triangle,  program computes and displays the perimeter and area

*/

#include <iostream>
#include <math.h>
#include <assert.h>

using namespace std;

double findPerimeter(double, double, double);
double findArea(double, double, double, double);
bool isItATriangle(double, double, double);


bool isItATriangle(double a, double b, double c) {
//a+b>c
//b+c>a
//c+a>b
if (a+b > c) {
     if (b+c > a){
         if (c+a> b)
        {
            return true;
        }
    }
}
else return false;
}

double findPerimeter(double A, double B, double C) {
//perimeter = three sides added together
return (A+B+C);
}

double findArea(double A, double B, double C, double P) {
    /*
    heron's formula:
    sqrt( s((s-a) * (s-b) * (s-c)))
    s= half of perimeter
    a-c = sides a,b,c
    */
double Area = 0;
double s = P/2;

Area = sqrt(s*((s-A)*(s-B)*(s-C)));

return Area;

}

int main (int argc, char *argv[]) {
double perimeter;
double sideA;
double sideB;
double sideC;
double area;
bool isitTriangle;

cout << "Please enter the lengths of each side of the triangle separated by a space: " << endl;
cin >> sideA >> sideB >> sideC;

perimeter = findPerimeter(sideA, sideB, sideC);
// cout << "DEBUG: perimeter is: " << perimeter << endl;

area = findArea(sideA, sideB, sideC, perimeter);
// cout << "DEBUG: area is :" << area << endl;

isitTriangle = isItATriangle(sideA, sideB, sideC);


cout << "Your Triangle's Perimeter is: " << perimeter << endl;
cout << "Your Triangle's Area is: " << area << endl;
cout << "These sides will create a triangle" << boolalpha(isitTriangle) << endl;

    return 0;}



// test function that test findArea function with test cases
void test()
{
//     float result =  findDistance1(4, 3, 5, 1);
//     float expected = 2.236067f;
//     assert( fabs(result - expected) <= epsilon); //accept the result if it's less than the error of margin
//     // FIXME8 - add at least two more test cases #FIXED
//     cerr << "all tests passed..." << endl;

float result[4];
result[0] = findArea(1,2,3,6);
result[1] = findArea(3,4,5,12);
result[2] = findArea(3,3,3,9);
result[3] = findArea(5,5,7,17);

float expected[4];
    expected[0] = 0.0f;
    expected[1] = 6.0f;
    expected[2] = 3.89711f;
    expected[3] = 12.4975f;

for (int i = 0; i < 4; i++) {
assert( fabs(result[i] - expected[i]) <= .1);
}
cerr << "all tests passed..." << endl;
