/*
Tyrel Boese
CSCI-111 HW-8 File-IO


create struct of student data
create input file stream / prompt for input file name
read student data to vectors within struct
calculate statistics from student vectors
    avg. test score
    letter grade (A-F)


append those stats to student
sort students by average test score
    calculate class mins, maxes, averages
create output stream / prompt for output file name
write student vectors to output file in a readable format
*/

#include <string>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <algorithm>
using namespace std;

struct student {
    string fName;
    string lName;
    float test1;
    float test2;
    float test3;
    float test4;
    float testAverage;
    char grade;
    };

struct CLstat {
    float max;
    float min;
    float avg;
    float tmp;
    float As;
    float Bs;
    float Cs;
    float Ds;
    float Fs;
    int aCount;
    int bCount;
    int cCount;
    int dCount;
    int fCount;
};

struct Output {
    const int width;
    const char separator;
    const string alignment;
};
//print functions for debugging
template <class Element> void printStudent(Element, Output);
void printStudents(vector<student>, CLstat, CLstat, CLstat, CLstat, CLstat);
void printDivider(Output);

void readData(string, vector<student>&);
void writeData(ostream&, vector<student>&, CLstat&, CLstat&, CLstat&, CLstat&, CLstat&); // wrapper for writing functions
template <class Element> void writeStudent(Element, Output, ostream&); //template function to print lines of data
void writeDivider(Output, ostream&); // draws a line

void studentAvg( vector<student>&);

void studentLetter(vector<student>&);
char letterGrade(float);
int percentify(float);

float classAvg( vector<student>&);
float classMin(vector<student>&);
float classMax(vector<student>&);
void classStats(vector<student>&, CLstat&, CLstat&, CLstat&, CLstat&, CLstat&);

void sortClass(vector<student>&);

void test();
void printVec(vector<student>&);

int main(int argc, char * argv[]){
//     if (strcmp(argv[1], "test") == 0)
//  {
//     test();
string infile;
string outfile = "sortedData";
vector<student> students;

CLstat test1;
CLstat test2;
CLstat test3;
CLstat test4;
CLstat letter;


cout << "enter the input file name: " << endl;
cin >> infile;
//DEBUG (set infile to classData for laziness)
// infile = "classData";
cout << "enter the output file name: " << endl;
cin >> outfile;

readData(infile, students); //read input file to students array
// printVec(students); //Debug

studentAvg(students); //calculate averages and add to students array
studentLetter(students); // calculate letter grade and add to array

classStats(students, test1, test2, test3, test4, letter); // calculate class statistics, save them to struct variables...
// cout << "test1 max: " << test1.max << endl; //DEBUG
// cout << "test1 avg: " << test1.avg << endl; //DEBUG
// cout << "test1 total: " << test1.tmp << endl; //DEBUG
// cout << "number of As" << letter.aCount << endl; //DEBUG

// printVec(students); //Debug

sortClass(students);

// printStudents(students, test1, test2, test3, test4, letter); //DEBUG

// printVec(students); //Debug

ofstream fout;
fout.open(outfile);

writeData(fout, students, test1, test2, test3, test4, letter);

    fout.close();
}

void readData(string input, vector<student> & students){
    fstream fin;
    fin.open(input);
    student tmp;

    while (!fin.eof()){
        // student student;
        fin >> tmp.fName >> tmp.lName >> tmp.test1 
        >> tmp.test2 >> tmp.test3 >> tmp.test4;
        students.push_back(tmp);
    }
    //  printVec(students);
    fin.close();
}

void studentLetter(vector<student> &students){
for (int i=0; i < students.size(); i++){
    students[i].grade = letterGrade(students[i].testAverage);
}
}

char letterGrade(float score){
if (score >= 90){
    return 'A';
}if (score >= 80){
    return 'B';
}if (score >= 70){
    return 'C';
}if (score >= 60){
    return 'D';
}else return 'F';
}

void printVec(vector<student> &students){
    for (auto& n : students){
        cout << "fName: " << n.fName << "lName: " << n.lName << endl
        << "Avg Test: " << n.testAverage << "Grade: " << n.grade << endl;
    }
}

void studentAvg( vector<student> &students){
    // printVec(students); //Debug
    // for (auto& test : students){
    //     test.testAverage = (test.test1+test.test2+test.test3+test.test4)/4;
    //     cout << test.testAverage << " ? " << endl;
    //     // cout << test.testAverage << "test average:" << endl;
    // }
    for (int i = 0; i < students.size(); i++){
        students[i].testAverage = (students[i].test1 + students[i].test2 + students[i].test3 + students[i].test4) / 4;
    }
}

void classStats(vector<student>& students, CLstat &test1, CLstat &test2, CLstat &test3, CLstat &test4, CLstat &letter){
    // CLstat test1;
    // CLstat test2;
    // CLstat test3;
    // CLstat test4;
    // CLstat letter;

    float size = students.size();

    // cout << "first entry in student: " << students[0].fName << "their test average: " << students[0].testAverage; //Debug

    test1.min = students.front().test1; // set minimums and maximums to first entry in vector... or 100 / 0?
    test2.min = students[0].test2;
    test3.min = students[0].test3;
    test4.min = students[0].test4;    
    
    test1.max = 0;
    test2.max = students[0].test2;
    test3.max = students[0].test3;
    test4.max = students[0].test4;

    test1.tmp = 0.0; // set temp variable to 0
    test2.tmp = 0.0; // used to keep total of each entry
    test3.tmp = 0.0;
    test4.tmp = 0.0;

    letter.aCount = 0;
    letter.bCount = 0;
    letter.cCount = 0;
    letter.dCount = 0;
    letter.fCount = 0;


    for (int n=0; n < size; n++){
        // cout << "student: " << students[n].fName << "test 1: " << students[n].test1 << endl; //DEBUG (working...)

        test1.tmp += students[n].test1; //add up every element of tests 1,2,3,4 respectively...
        test2.tmp += students[n].test2;
        test3.tmp += students[n].test3;
        test4.tmp += students[n].test4;

        // cout << "test1 running total: " << test1.tmp << endl; //DEBUG (working...)

        if (students[n].test1 < test1.min) //if test value is greater than current max, it is the new max
            test1.min = students[n].test1; // if test value is less than current minimum, it is the new minimum
        if (students[n].test1 > test1.max)
            test1.max = students[n].test1;

        if (students[n].test2 < test2.min)
            test2.min = students[n].test2;
        if (students[n].test2 > test2.max)
            test2.max = students[n].test2;

        if (students[n].test3 < test3.min)
            test3.min = students[n].test3;
        if (students[n].test3 > test3.max)
            test3.max = students[n].test3;

        if (students[n].test4 < test4.min)
            test4.min = students[n].test4;
        if (students[n].test4 > test4.max)
            test4.max = students[n].test4;

        // cout << "test1 current minimum: " << test1.min << endl; // DEBUG (working...)
        // cout << "test1 current maximum: " << test1.max << endl; // DEBUG (working...)

        switch (students[n].grade){
            case 'A':
                letter.aCount ++;
                break;
            case 'B':
                letter.bCount ++;
                break;
            case 'C':
                letter.cCount ++;
                break;
            case 'D':
                letter.dCount ++;
                break;
            case 'F':
                letter.fCount ++;
                break;}

    }

    // cout << "size: " << size; // DEBUG
    // cout << "test1.tmp " << test1.tmp << endl; //DEBUG

    test1.avg = test1.tmp/size;
    test2.avg = test2.tmp/size;
    test3.avg = test3.tmp/size;
    test4.avg = test4.tmp/size;

    // cout << "test1.avg: " << test1.avg << endl; //DEBUG

    letter.As = letter.aCount / size;
    letter.Bs = letter.bCount / size;
    letter.Cs = letter.cCount / size;
    letter.Ds = letter.dCount / size;
    letter.Fs = letter.fCount / size;

    // cout << "letter.As: " << letter.As << endl; //DEBUG

}

void sortClass(vector<student>& students){
	bool sorted = false;
    size_t size = students.size();
    
	for (int i = 0; i < size; i++) {
    	sorted = true;
		for (int j = 0; j < size-i-1; j++) {
			if (students[j].testAverage < students[j+1].testAverage) {
                swap(students[j], students[j+1]);
				sorted = false;
			} if (students[j].testAverage == students[j+1].testAverage && students[j].lName > students[j+1].lName ) {
                swap(students[j], students[j+1]);
				sorted = false;
            }
		}
		if (sorted) break;
	}
}

template <class Element> void printStudent(Element element, Output m){
    cout << left << setprecision(4) << setw(m.width) << setfill(m.separator) << element;
}
void printDivider(Output m){
    cout << left << setw(m.width) << setfill(m.separator) << m.separator << endl;
}

int percentify(float grade){
    int percent;

    percent = (grade * 100);

    return percent;
}

void printStudents(vector<student> students, CLstat firstTest, CLstat secondTest, CLstat thirdTest, CLstat fourthTest, CLstat letterGrade){
    Output fName = { .alignment = "left", .separator = ' ', .width = 16};
    Output lName = { .alignment = "left", .separator = ' ', .width = 16};
    Output test1 = { .alignment = "left", .separator = ' ', .width = 12};
    Output test2 = { .alignment = "left", .separator = ' ', .width = 12};
    Output test3 = { .alignment = "left", .separator = ' ', .width = 12};
    Output test4 = { .alignment = "left", .separator = ' ', .width = 12};
    Output testavg = { .alignment = "left", .separator = ' ', .width = 12};
    Output grade = { .alignment = "left", .separator = ' ', .width = 12};
    Output format = { .alignment = "left", .separator = '=', .width = 104};
    Output Class = { .alignment = "left", .separator = ' ', .width = 32};
    Output percent = { .alignment = "left", .separator = ' ', .width = 2};
    Output number = { .alignment = "right", .separator = ' ', .width = 2};
    int a = percentify(letterGrade.As);
    int b = percentify(letterGrade.Bs);
    int c = percentify(letterGrade.Cs);
    int d = percentify(letterGrade.Ds);
    int f = percentify(letterGrade.Fs);


//-----------------------
    printDivider(format);
//-----------------------
        printStudent("First Name", fName);
        printStudent("Last Name", lName);
        printStudent("Test 1 (%)", test1);
        printStudent("Test 2 (%)", test2);
        printStudent("Test 3 (%)", test3);
        printStudent("Test 4 (%)", test4);
        printStudent("Average", testavg);
        printStudent("Grade", grade);
        cout << endl;
//-----------------------
    printDivider(format);
//-----------------------

    for (auto student : students){
        printStudent(student.fName, fName);
        printStudent(student.lName, lName);
        printStudent(student.test1, test1);
        printStudent(student.test2, test2);
        printStudent(student.test3, test3);
        printStudent(student.test4, test4);
        printStudent(student.testAverage, testavg);
        printStudent(student.grade, grade);
        cout << endl;
    }
//-----------------------
    printDivider(format);
//-----------------------
    printStudent("Class Average: ", Class); 
    printStudent(firstTest.avg, test1);
    printStudent(secondTest.avg, test2);
    printStudent(thirdTest.avg, test3);
    printStudent(fourthTest.avg, test4);
    cout << endl; //class avg    
    printStudent("Class Max: ", Class); 
    printStudent(firstTest.max, test1);
    printStudent(secondTest.max, test2);
    printStudent(thirdTest.max, test3);
    printStudent(fourthTest.max, test4);
    cout << endl; //class max
    printStudent("Class Min:", Class); 
    printStudent(firstTest.min, test1);
    printStudent(secondTest.min, test2);
    printStudent(thirdTest.min, test3);
    printStudent(fourthTest.min, test4);
    cout << endl; //class min
//-----------------------
    printDivider(format);
//-----------------------

    printStudent("Total (%) A's:", Class);
    printStudent(a, number);
    printStudent('%', percent);
    cout << endl;
    printStudent("Total (%) B's:", Class);
    printStudent(b, number);
    printStudent('%', percent);
    cout << endl;
    printStudent("Total (%) C's:", Class);
    printStudent(c, number);
    printStudent('%', percent);
    cout << endl;
    printStudent("Total (%) D's:", Class);
    printStudent(d, number);
    printStudent('%', percent);
    cout << endl;
    printStudent("Total (%) F's:", Class);
    printStudent(f, number);
    printStudent('%', percent);
    cout << endl;
//-----------------------
    printDivider(format);
//-----------------------
}


template <class Element> void writeStudent(Element element, Output m, ostream &fout){
    fout << left << setprecision(4) << setw(m.width) << setfill(m.separator) << element;

}

void writeDivider(Output m, ostream &fout){
    fout << left << setw(m.width) << setfill(m.separator) << m.separator << endl;
}
void writeData(ostream &fout, vector<student> &students, CLstat &firstTest, CLstat &secondTest, CLstat &thirdTest, CLstat &fourthTest, CLstat &letterGrade){
    // fstream fout;
    // fout.open(output);

    Output fName = { .alignment = "left", .separator = ' ', .width = 16};
    Output lName = { .alignment = "left", .separator = ' ', .width = 16};
    Output test1 = { .alignment = "left", .separator = ' ', .width = 12};
    Output test2 = { .alignment = "left", .separator = ' ', .width = 12};
    Output test3 = { .alignment = "left", .separator = ' ', .width = 12};
    Output test4 = { .alignment = "left", .separator = ' ', .width = 12};
    Output testavg = { .alignment = "left", .separator = ' ', .width = 12};
    Output grade = { .alignment = "left", .separator = ' ', .width = 12};
    Output format = { .alignment = "left", .separator = '=', .width = 104};
    Output Class = { .alignment = "left", .separator = ' ', .width = 32};
    Output percent = { .alignment = "left", .separator = ' ', .width = 2};
    Output number = { .alignment = "right", .separator = ' ', .width = 2};

    int a = percentify(letterGrade.As);
    int b = percentify(letterGrade.Bs);
    int c = percentify(letterGrade.Cs);
    int d = percentify(letterGrade.Ds);
    int f = percentify(letterGrade.Fs);


//-----------------------
    writeDivider(format, fout);
//-----------------------
        writeStudent("First Name", fName, fout);
        writeStudent("Last Name", lName, fout);
        writeStudent("Test 1 (%)", test1, fout);
        writeStudent("Test 2 (%)", test2, fout);
        writeStudent("Test 3 (%)", test3, fout);
        writeStudent("Test 4 (%)", test4, fout);
        writeStudent("Average", testavg, fout);
        writeStudent("Grade", grade, fout);
        fout << endl;
//-----------------------
    writeDivider(format, fout);
//-----------------------

    for (auto student : students){
        writeStudent(student.fName, fName, fout);
        writeStudent(student.lName, lName, fout);
        writeStudent(student.test1, test1, fout);
        writeStudent(student.test2, test2, fout);
        writeStudent(student.test3, test3, fout);
        writeStudent(student.test4, test4, fout);
        writeStudent(student.testAverage, testavg, fout);
        writeStudent(student.grade, grade, fout);
        fout << endl;
    }
//-----------------------
    writeDivider(format, fout);
//-----------------------
    writeStudent("Class Average: ", Class, fout); 
    writeStudent(firstTest.avg, test1, fout);
    writeStudent(secondTest.avg, test2, fout);
    writeStudent(thirdTest.avg, test3, fout);
    writeStudent(fourthTest.avg, test4, fout);
    fout << endl; //class avg    
    writeStudent("Class Max: ", Class, fout); 
    writeStudent(firstTest.max, test1, fout);
    writeStudent(secondTest.max, test2, fout);
    writeStudent(thirdTest.max, test3, fout);
    writeStudent(fourthTest.max, test4, fout);
    fout << endl; //class max
    writeStudent("Class Min:", Class, fout); 
    writeStudent(firstTest.min, test1, fout);
    writeStudent(secondTest.min, test2, fout);
    writeStudent(thirdTest.min, test3, fout);
    writeStudent(fourthTest.min, test4, fout);
    fout << endl; //class min
//-----------------------
    writeDivider(format, fout);
//-----------------------

    writeStudent("Total (%) A's:", Class, fout);
    writeStudent(a, number, fout);
    writeStudent('%', percent, fout);
    fout << endl;
    writeStudent("Total (%) B's:", Class, fout);
    writeStudent(b, number, fout);
    writeStudent('%', percent, fout);
    fout << endl;
    writeStudent("Total (%) C's:", Class, fout);
    writeStudent(c, number, fout);
    writeStudent('%', percent, fout);
    fout << endl;
    writeStudent("Total (%) D's:", Class, fout);
    writeStudent(d, number, fout);
    writeStudent('%', percent, fout);
    fout << endl;
    writeStudent("Total (%) F's:", Class, fout);
    writeStudent(f, number, fout);
    writeStudent('%', percent, fout);
    fout << endl;
//-----------------------
    writeDivider(format, fout);
//-----------------------
    



    // write contents of students[] array to file

    // fout.close();
}


