//header for computer AI
#pragma once

#include <string>
#include <vector>

namespace compAI {

    bool checkLine(std::vector<char>&, int, int, char, int);
    bool win(std::vector<char>&, char, char);
    bool blockwin(std::vector<char>&, char, char);
    bool fork(std::vector<char>&, char, char);
    bool blockfork(std::vector<char>&, char, char);
    bool center(std::vector<char>&, char, char);
    bool oppositecorner(std::vector<char>&, char, char);
    bool emptycorner(std::vector<char>&, char, char);
    bool emptyside(std::vector<char>&, char, char);
    int randomsquare(std::vector<char>&, char, char);

    void pcTurn(std::vector<char>&, int, char, char);

}