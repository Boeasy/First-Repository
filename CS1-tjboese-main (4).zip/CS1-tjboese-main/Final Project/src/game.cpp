//game functions

#include <iostream>
#include <string>
#include <vector>
#include "game.h"
#include "format.h"
#include "tictacfoe.h"

namespace game {
    // game funtions and variables here....
    bool checksquare(int square, char token, std::vector<char> &gameboard){
        //checks for token at board[square]
        if (gameboard[square] == token){
            return true;
        }
        return false;
    }

    void chooseSquare(std::vector<char> &gameboard, char token, char pctoken){
        int input;
        //enter two integers between 1-9 separated by a space to indicate your selection
        std::cout << "Your Turn! Select a Square (1-9)" << std::endl;
        do {
            std::cin >> input;
            if (gameboard.at(input-1) == token){
                    //[input - 1]
                std::cout << "You've already picked that square!" << std::endl;
            }            
            if (gameboard.at(input-1) == pctoken){
                std::cout << "That square is taken!" << std::endl;
            }
            std::cout << "You've chosen square: " << input << std::endl;
        } while (gameboard.at(input-1) != ' ');
        //change board[input]
        gameboard.at(input-1) = token;

    }

    bool checkLine(std::vector<char> &gameboard, int pos, int step){ //found arithmetic progression on codereview.stackexchange.com/questions/268345/tic-tac-toe-in-c-with-classes
        char token = gameboard[pos];
        pos += step;
        if (gameboard[pos] != token) {return false;}
        pos += step;
        if (gameboard[pos] != token) {return false;}
        return true;
    }



    char gameEnd(){
        /*
        fileio for stat recording
        ask player to play again or go to main menu
        */
       char input;

       std::cout << "play again? Y/N" << std::endl;
        do{
        std::cin >> input;
        } while (input != 'y' && input != 'Y' && input != 'n' && input != 'N');

        return input;

    }

    bool checkWin(std::vector<char> &gameboard, char token){
        /*
        check board for a win...
        */
       if (
        // horizontals..
        (gameboard[0] == token && gameboard[1] == token && gameboard[2] == token)||
        (gameboard[3] == token && gameboard[4] == token && gameboard[5] == token)||
        (gameboard[6] == token && gameboard[7] == token && gameboard[8] == token)||
        // verticals
        (gameboard[0] == token && gameboard[3] == token && gameboard[6] == token)||
        (gameboard[1] == token && gameboard[4] == token && gameboard[7] == token)||
        (gameboard[2] == token && gameboard[5] == token && gameboard[8] == token)||
        //diagonals
        (gameboard[0] == token && gameboard[4] == token && gameboard[8] == token)||
        (gameboard[2] == token && gameboard[4] == token && gameboard[6] == token)
       )
       {
        return true;

       }
       return false;
       //todo: add some sort of logic for a draw?
    }

    void XsorOs(char& token, char& pctoken, bool& yourTurn){    // choose Xs or Os
        /*
        cout "X's or O's?"
        do while loop until token = X or O
        pctoken = the other one
        set bool yourturn = true for X or false for O
        */
       std::cout << "X's or O's?" << std::endl;

       do {
        std::cin >> token;
       } while (token != 'X' && token != 'O');

       if (token == 'X') {
        pctoken = 'O';
        yourTurn = true;
        }
        if (token == 'O'){
            pctoken = 'X';
            yourTurn = false;
        }

    } 

    char gameplay(int& gameDifficulty, std::vector<char> &gameboard, bool yourTurn, char pctoken, char token){
        char draw = 'd';
        gameDifficulty = 6;
        int counter = 0;
        do { //first turn excluded because can't win on turn 1 ... do while loop
                format::printBoard(gameboard);
                if (yourTurn == true){
                    chooseSquare(gameboard, token, pctoken);
                    yourTurn = false;
                    counter++; //check for draw
                    continue; //break out of do while loop so not stuck in infinite back and forth...
                }
                if (yourTurn == false){
                    compAI::pcTurn(gameboard, gameDifficulty, pctoken, token);
                    //^somewhere in this section is the problem
                    yourTurn = true;
                    counter++; //check for draw
                    continue;
                }
            } 
            while (!checkWin(gameboard, token) && !checkWin(gameboard, pctoken) && counter < 9); // while a win hasn't been declared, keep going
        //return character of winner, or d for draw;
        if (checkWin(gameboard, token)){
            return token;
        } 
        if (checkWin(gameboard, pctoken)){
            return pctoken;
        }
        return draw;
    }

    void gameStart(){
        char keepgoing = 'Y';
        // token = 'X'; // initializing player token to Xs
        // pctoken = 'O'; // default pc is Os
        // yourTurn = true; //default it's your turn

        std::vector<char> gameboard; // = {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',' '};
        for (int i = 1; i < 10; i++){
            gameboard.push_back(i);
        }
        // char* gameboard = new char[9];
        char* token = new char;
        char* pctoken = new char;
        bool* yourTurn = new bool;
        int* gameDifficulty = new int;

        

        do {
        XsorOs(*token, *pctoken, *yourTurn); // sets player token to X or O and pc to opposite
        std::fill(gameboard.begin(), gameboard.end(), ' ');
        // for (int i = 0; i < 9; i++){
        //     gameboard[i] = ' '; // reset board
        // }

        char result = gameplay(*gameDifficulty, gameboard, *yourTurn, *pctoken, *token);

        if (result == *token){
            std::cout << "Player wins!" << std::endl;

        }
        if (result == *pctoken){
            std::cout << "PC wins!" << std::endl;

        }
        if (result == 'd'){
            std::cout << "It's a Draw!" << std::endl;
        }

        keepgoing = gameEnd();

        }
        while (keepgoing != 'N' || keepgoing != 'n');
        /*
        to do add in some file IO for scores...
        
        */
    //    delete[] gameboard;
        delete token;
        delete pctoken;
        delete yourTurn;  
        delete gameDifficulty;  
        }


} // end of namespace bracket don't delete
