//header file for menu format
#pragma once

#include <string>

namespace mainMenu {
    
    void option(); // takes you to menu option
    void choosePlayer(std::string&); //changes player name variable...
    int changeDifficulty(); // picks which logic the computer opponent will use...
    void leaderBoard(); // prints out 10 highest scoring players
    void playerStats(); // prints out statistics of current player
    bool quit(); // quit game

}