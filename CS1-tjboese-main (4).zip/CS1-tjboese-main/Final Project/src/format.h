// header for formatting files and printing functions
#pragma once

#include <string>
#include <vector>

namespace format {

    void printBoard(std::vector<char>&); //prints board
    void printScores(); // prints leaderboard with game stats
    void mainMenu(); //prints main menu

}

