moving comments of algorithm steps over here...

        /*
        multiple difficulty modes based on difficulty variable:

        from wikipedia/wiki/Tic-tac-toe algorithm:

        1) Win: if pc has two in a row it picks the third
        2) Block: if opponent has two in a row pc blocks the third
        3) Fork: pc aims to create a fork
        4) Block fork: pc blocks opponent from creating a fork
        5) Center: picks center block
        6) Opposite corner: if opponent picks a corner, pc picks opposite corner
        7) empty corner: pc picks a corner square
        8) empty side: pc picks the middle square of one of the sides

        difficulty levels 1-9 will toggle through these steps, with steps past the difficulty level being replaced by 'pick random block'
        */



old fork function:
    bool fork(std::string& direction){
        /*
        checks for a fork...
        1 token and 2 empty in a line, from that token 2 tokens and 1 empty....
        check line must be positive twice to return true
        */
            for (int i = 0; i < 3; i++){
            //horizontals * verticals
            if (
                (checkLine(i*3, 1, pctoken, 1) && checkLine(i*3, 1, ' ', 2)) && // 2 open horizontal spaces & 1 pc token
                (checkLine(i, 3, pctoken, 1) && checkLine(i, 3, ' ', 2)) //2 open vertical spaces & 1 pc tokens
                ) {
                    direction = "hvf";
                    direction += std::to_string(i); //check which box makes the fork **not i, dependent on i**
                    return true;
                    }            
            //horizontals * diagonals
            if (
                checkLine(i*3, 1, pctoken, 2) && //horizontal
               ( (checkLine(0, 4, pctoken, 2) || checkLine(2, 2, pctoken, 2)) || // diagonal 1 or 2
                 (checkLine(0, 4, pctoken, 2) || checkLine(2, 2, pctoken, 2))
                )) {return true;}

            //verticals * horizontals
            if (
                checkLine(i*3, 1, pctoken, 2) &&
                checkLine(i*3, 1, pctoken, 2)
                ) {return true;}        
            //verticals * diagonals
            if (
                checkLine(i*3, 1, pctoken, 2) &&
               ( (checkLine(0, 4, pctoken, 2) || checkLine(2, 2, pctoken, 2)) ||
                 (checkLine(0, 4, pctoken, 2) || checkLine(2, 2, pctoken, 2))
                )) {return true;}

                //diagonals * diagonals
            return (checkLine(0, 4, pctoken, 2) && checkLine(2, 2, pctoken, 2)); // 2 & 1
            return (checkLine(0, 4, pctoken, 2) && checkLine(2, 2, pctoken, 2)); // 1 & 2
        }
    }

old win function:
        bool win(std::string& direction){
        //checks for 2 pc tokens in a row
        for (int i = 0; i < 3; i++){
            //horizontals
            if (checkLine(i*3, 1, pctoken, 2)) {
                direction = "hw";
                direction += std::to_string(i*3);
                return true;}
            //verticals
            if (checkLine(i, 3, pctoken, 2)) {
                direction = "vw";
                direction += std::to_string(i);
                return true;}
        } //diagonals
            if (checkLine(0, 4, pctoken, 2) || checkLine(2, 2, pctoken, 2)){
                direction = "dw";
                return true;
            };
    }

findsquare function, removed in favor of letting each function provide the correct index instead of bools + extra function:

        int findSquare(std::string direction){
        int index;
        //wins
        if (direction == "hw0"){ // return value of the one that comes up empty...
            game::checksquare(0);
            game::checksquare(1);
            game::checksquare(2);
        }
        if (direction == "hw3"){ // return value of the one that comes up empty...
            game::checksquare(3);
            game::checksquare(4);
            game::checksquare(5);
        }
        if (direction == "hw6"){ // return value of the one that comes up empty...
            game::checksquare(6);
            game::checksquare(7);
            game::checksquare(8);
        }                      
        if (direction == "vw0"){ // return value of the one that comes up empty...
            game::checksquare(0);
            game::checksquare(3);
            game::checksquare(6);
        }
        if (direction == "vw1"){ // return value of the one that comes up empty...
            game::checksquare(1);
            game::checksquare(4);
            game::checksquare(7);
        }
        if (direction == "vw3"){ // return value of the one that comes up empty...
            game::checksquare(2);
            game::checksquare(5);
            game::checksquare(8);
        } 
        if (direction == "dw"){ // return value of the one that comes up empty...

            game::checksquare(0); //diagonal 1
            game::checksquare(4);
            game::checksquare(8);

            game::checksquare(6); //diagonal 2
            game::checksquare(4);
            game::checksquare(2);
        } 
        //blocks
        if (direction == "hb0"){ // return value of the one that comes up empty...
            game::checksquare(0);
            game::checksquare(1);
            game::checksquare(2);
        }
        if (direction == "hb3"){ // return value of the one that comes up empty...
            game::checksquare(3);
            game::checksquare(4);
            game::checksquare(5);
        }
        if (direction == "hb6"){ // return value of the one that comes up empty...
            game::checksquare(6);
            game::checksquare(7);
            game::checksquare(8);
        }                      
        if (direction == "vb0"){ // return value of the one that comes up empty...
            game::checksquare(0);
            game::checksquare(3);
            game::checksquare(6);
        }
        if (direction == "vb1"){ // return value of the one that comes up empty...
            game::checksquare(1);
            game::checksquare(4);
            game::checksquare(7);
        }
        if (direction == "vb3"){ // return value of the one that comes up empty...
            game::checksquare(2);
            game::checksquare(5);
            game::checksquare(8);
        } 
        if (direction == "db"){ // return value of the one that comes up empty...

            game::checksquare(0); //diagonal 1
            game::checksquare(4);
            game::checksquare(8);

            game::checksquare(6); //diagonal 2
            game::checksquare(4);
            game::checksquare(2);
        } 
        //forks
        if (direction == "hvf0"){ // fork 0 = 0,1,2,3,6
            board[0] = pctoken;
        }
        if (direction == "hvf0"){ // fork 0 = 0,1,2,3,6
            game::checksquare(0);
            game::checksquare(1);
            game::checksquare(2);
            game::checksquare(3);
            game::checksquare(6);
        }

        
                     
        return index;
    }